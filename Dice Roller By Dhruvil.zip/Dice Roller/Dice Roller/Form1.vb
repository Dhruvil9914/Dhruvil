﻿Public Class Form1
    Private click As Integer = 0
    Private p1score As Integer = 0
    Private p2score As Integer = 0
    Private p1score2 As Integer = 0
    Private p2score2 As Integer = 0
    Private p1score3 As Integer = 0
    Private p2score3 As Integer = 0


    '****************************************************************************************************
    'player1 dice 1

    Private Sub tmrDice1_Tick(sender As Object, e As EventArgs) Handles tmrDice1.Tick
        Static controller As Integer

        controller = controller + 1
        If controller = 1 Then
            PicPlayer1Dice1.Image = My.Resources.dice1
        End If

        If controller = 2 Then
            PicPlayer1Dice1.Image = My.Resources.dice2
        End If

        If controller = 3 Then
            PicPlayer1Dice1.Image = My.Resources.dice3
        End If

        If controller = 4 Then
            PicPlayer1Dice1.Image = My.Resources.dice4
        End If

        If controller = 5 Then
            PicPlayer1Dice1.Image = My.Resources.dice5
        End If

        If controller = 6 Then
            PicPlayer1Dice1.Image = My.Resources.dice6
        End If


        '****************************************************************************************************
        'player1 dice 2



        If controller = 1 Then
            PicPlayer1Dice2.Image = My.Resources.dice1
        End If

        If controller = 2 Then
            PicPlayer1Dice2.Image = My.Resources.dice2
        End If

        If controller = 3 Then
            PicPlayer1Dice2.Image = My.Resources.dice3
        End If

        If controller = 4 Then
            PicPlayer1Dice2.Image = My.Resources.dice4
        End If

        If controller = 5 Then
            PicPlayer1Dice2.Image = My.Resources.dice5
        End If

        If controller = 6 Then
            PicPlayer1Dice2.Image = My.Resources.dice6
        End If


        '****************************************************************************************************
        'player2  dice 1

        If controller = 1 Then
            PicPlayer2Dice1.Image = My.Resources.dice1
        End If

        If controller = 2 Then
            PicPlayer2Dice1.Image = My.Resources.dice2
        End If

        If controller = 3 Then
            PicPlayer2Dice1.Image = My.Resources.dice3
        End If

        If controller = 4 Then
            PicPlayer2Dice1.Image = My.Resources.dice4
        End If

        If controller = 5 Then
            PicPlayer2Dice1.Image = My.Resources.dice5
        End If

        If controller = 6 Then
            PicPlayer2Dice1.Image = My.Resources.dice6
        End If


        '****************************************************************************************************
        'player2  dice 2

        If controller = 1 Then
            PicPlayer2Dice2.Image = My.Resources.dice1
        End If

        If controller = 2 Then
            PicPlayer2Dice2.Image = My.Resources.dice2
        End If

        If controller = 3 Then
            PicPlayer2Dice2.Image = My.Resources.dice3
        End If

        If controller = 4 Then
            PicPlayer2Dice2.Image = My.Resources.dice4
        End If

        If controller = 5 Then
            PicPlayer2Dice2.Image = My.Resources.dice5
        End If

        If controller = 6 Then
            PicPlayer2Dice2.Image = My.Resources.dice6
        End If


    End Sub

    Private Sub btnPlay_Click(sender As Object, e As EventArgs) Handles btnPlay.Click

        Static dice1 As Integer
        Static dice2 As Integer
        Static dice3 As Integer
        Static dice4 As Integer
        Static dice5 As Integer
        Static dice6 As Integer

        Static score1 As Integer
        Static score2 As Integer
        Dim result As Integer
        Dim rand As Random

        If result = 1 Then
            dice1 = dice1 + 1
            PicPlayer1Dice1.Image = My.Resources.dice1
            BtnScore1.Text = "dice1::" & dice1

        End If



    End Sub
End Class





