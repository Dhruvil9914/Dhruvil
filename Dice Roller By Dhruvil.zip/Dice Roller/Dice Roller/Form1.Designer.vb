﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblPlayer1 = New System.Windows.Forms.Label()
        Me.lblPlayer2 = New System.Windows.Forms.Label()
        Me.PicDice1 = New System.Windows.Forms.PictureBox()
        Me.PicDice6 = New System.Windows.Forms.PictureBox()
        Me.PicDice4 = New System.Windows.Forms.PictureBox()
        Me.PicDice3 = New System.Windows.Forms.PictureBox()
        Me.PicDice2 = New System.Windows.Forms.PictureBox()
        Me.PicDice5 = New System.Windows.Forms.PictureBox()
        Me.PicPlayer1Dice1 = New System.Windows.Forms.PictureBox()
        Me.tmrDice1 = New System.Windows.Forms.Timer(Me.components)
        Me.PicPlayer2Dice2 = New System.Windows.Forms.PictureBox()
        Me.PicPlayer2Dice1 = New System.Windows.Forms.PictureBox()
        Me.PicPlayer1Dice2 = New System.Windows.Forms.PictureBox()
        Me.btnPlay = New System.Windows.Forms.Button()
        Me.BtnScore1 = New System.Windows.Forms.Button()
        Me.BtnScore2 = New System.Windows.Forms.Button()
        CType(Me.PicDice1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicDice6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicDice4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicDice3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicDice2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicDice5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPlayer1Dice1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPlayer2Dice2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPlayer2Dice1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPlayer1Dice2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblPlayer1
        '
        Me.lblPlayer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayer1.Location = New System.Drawing.Point(132, 84)
        Me.lblPlayer1.Name = "lblPlayer1"
        Me.lblPlayer1.Size = New System.Drawing.Size(137, 41)
        Me.lblPlayer1.TabIndex = 0
        Me.lblPlayer1.Text = "Player 1"
        '
        'lblPlayer2
        '
        Me.lblPlayer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayer2.Location = New System.Drawing.Point(583, 84)
        Me.lblPlayer2.Name = "lblPlayer2"
        Me.lblPlayer2.Size = New System.Drawing.Size(137, 41)
        Me.lblPlayer2.TabIndex = 1
        Me.lblPlayer2.Text = "Player 2"
        '
        'PicDice1
        '
        Me.PicDice1.Image = Global.Dice_Roller.My.Resources.Resources.dice1
        Me.PicDice1.Location = New System.Drawing.Point(93, 405)
        Me.PicDice1.Name = "PicDice1"
        Me.PicDice1.Size = New System.Drawing.Size(101, 78)
        Me.PicDice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDice1.TabIndex = 7
        Me.PicDice1.TabStop = False
        '
        'PicDice6
        '
        Me.PicDice6.Image = Global.Dice_Roller.My.Resources.Resources.dice6
        Me.PicDice6.Location = New System.Drawing.Point(711, 405)
        Me.PicDice6.Name = "PicDice6"
        Me.PicDice6.Size = New System.Drawing.Size(101, 78)
        Me.PicDice6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDice6.TabIndex = 6
        Me.PicDice6.TabStop = False
        '
        'PicDice4
        '
        Me.PicDice4.Image = Global.Dice_Roller.My.Resources.Resources.dice4
        Me.PicDice4.Location = New System.Drawing.Point(467, 405)
        Me.PicDice4.Name = "PicDice4"
        Me.PicDice4.Size = New System.Drawing.Size(101, 78)
        Me.PicDice4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDice4.TabIndex = 5
        Me.PicDice4.TabStop = False
        '
        'PicDice3
        '
        Me.PicDice3.Image = Global.Dice_Roller.My.Resources.Resources.dice3
        Me.PicDice3.Location = New System.Drawing.Point(345, 405)
        Me.PicDice3.Name = "PicDice3"
        Me.PicDice3.Size = New System.Drawing.Size(101, 78)
        Me.PicDice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDice3.TabIndex = 4
        Me.PicDice3.TabStop = False
        '
        'PicDice2
        '
        Me.PicDice2.Image = Global.Dice_Roller.My.Resources.Resources.dice2
        Me.PicDice2.Location = New System.Drawing.Point(213, 405)
        Me.PicDice2.Name = "PicDice2"
        Me.PicDice2.Size = New System.Drawing.Size(101, 78)
        Me.PicDice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDice2.TabIndex = 3
        Me.PicDice2.TabStop = False
        '
        'PicDice5
        '
        Me.PicDice5.Image = Global.Dice_Roller.My.Resources.Resources.dice5
        Me.PicDice5.Location = New System.Drawing.Point(589, 405)
        Me.PicDice5.Name = "PicDice5"
        Me.PicDice5.Size = New System.Drawing.Size(101, 78)
        Me.PicDice5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDice5.TabIndex = 2
        Me.PicDice5.TabStop = False
        '
        'PicPlayer1Dice1
        '
        Me.PicPlayer1Dice1.Image = Global.Dice_Roller.My.Resources.Resources.dice1
        Me.PicPlayer1Dice1.Location = New System.Drawing.Point(40, 168)
        Me.PicPlayer1Dice1.Name = "PicPlayer1Dice1"
        Me.PicPlayer1Dice1.Size = New System.Drawing.Size(121, 92)
        Me.PicPlayer1Dice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPlayer1Dice1.TabIndex = 8
        Me.PicPlayer1Dice1.TabStop = False
        '
        'tmrDice1
        '
        Me.tmrDice1.Enabled = True
        Me.tmrDice1.Interval = 100000
        '
        'PicPlayer2Dice2
        '
        Me.PicPlayer2Dice2.Image = Global.Dice_Roller.My.Resources.Resources.dice1
        Me.PicPlayer2Dice2.Location = New System.Drawing.Point(656, 168)
        Me.PicPlayer2Dice2.Name = "PicPlayer2Dice2"
        Me.PicPlayer2Dice2.Size = New System.Drawing.Size(121, 92)
        Me.PicPlayer2Dice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPlayer2Dice2.TabIndex = 9
        Me.PicPlayer2Dice2.TabStop = False
        '
        'PicPlayer2Dice1
        '
        Me.PicPlayer2Dice1.Image = Global.Dice_Roller.My.Resources.Resources.dice1
        Me.PicPlayer2Dice1.Location = New System.Drawing.Point(529, 168)
        Me.PicPlayer2Dice1.Name = "PicPlayer2Dice1"
        Me.PicPlayer2Dice1.Size = New System.Drawing.Size(121, 92)
        Me.PicPlayer2Dice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPlayer2Dice1.TabIndex = 10
        Me.PicPlayer2Dice1.TabStop = False
        '
        'PicPlayer1Dice2
        '
        Me.PicPlayer1Dice2.Image = Global.Dice_Roller.My.Resources.Resources.dice1
        Me.PicPlayer1Dice2.Location = New System.Drawing.Point(167, 168)
        Me.PicPlayer1Dice2.Name = "PicPlayer1Dice2"
        Me.PicPlayer1Dice2.Size = New System.Drawing.Size(121, 92)
        Me.PicPlayer1Dice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPlayer1Dice2.TabIndex = 11
        Me.PicPlayer1Dice2.TabStop = False
        '
        'btnPlay
        '
        Me.btnPlay.Location = New System.Drawing.Point(357, 194)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(100, 40)
        Me.btnPlay.TabIndex = 12
        Me.btnPlay.Text = "Roll"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'BtnScore1
        '
        Me.BtnScore1.Location = New System.Drawing.Point(21, 29)
        Me.BtnScore1.Name = "BtnScore1"
        Me.BtnScore1.Size = New System.Drawing.Size(100, 37)
        Me.BtnScore1.TabIndex = 13
        Me.BtnScore1.Text = "Score"
        Me.BtnScore1.UseVisualStyleBackColor = True
        '
        'BtnScore2
        '
        Me.BtnScore2.Location = New System.Drawing.Point(844, 29)
        Me.BtnScore2.Name = "BtnScore2"
        Me.BtnScore2.Size = New System.Drawing.Size(100, 37)
        Me.BtnScore2.TabIndex = 14
        Me.BtnScore2.Text = "Score"
        Me.BtnScore2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(956, 511)
        Me.Controls.Add(Me.BtnScore2)
        Me.Controls.Add(Me.BtnScore1)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.PicPlayer1Dice2)
        Me.Controls.Add(Me.PicPlayer2Dice1)
        Me.Controls.Add(Me.PicPlayer2Dice2)
        Me.Controls.Add(Me.PicPlayer1Dice1)
        Me.Controls.Add(Me.PicDice1)
        Me.Controls.Add(Me.PicDice6)
        Me.Controls.Add(Me.PicDice4)
        Me.Controls.Add(Me.PicDice3)
        Me.Controls.Add(Me.PicDice2)
        Me.Controls.Add(Me.PicDice5)
        Me.Controls.Add(Me.lblPlayer2)
        Me.Controls.Add(Me.lblPlayer1)
        Me.Enabled = False
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PicDice1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicDice6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicDice4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicDice3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicDice2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicDice5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPlayer1Dice1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPlayer2Dice2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPlayer2Dice1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPlayer1Dice2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblPlayer1 As Label
    Friend WithEvents lblPlayer2 As Label
    Friend WithEvents PicDice5 As PictureBox
    Friend WithEvents PicDice2 As PictureBox
    Friend WithEvents PicDice3 As PictureBox
    Friend WithEvents PicDice4 As PictureBox
    Friend WithEvents PicDice6 As PictureBox
    Friend WithEvents PicDice1 As PictureBox
    Friend WithEvents PicPlayer1Dice1 As PictureBox
    Friend WithEvents tmrDice1 As Timer
    Friend WithEvents PicPlayer2Dice2 As PictureBox
    Friend WithEvents PicPlayer2Dice1 As PictureBox
    Friend WithEvents PicPlayer1Dice2 As PictureBox
    Friend WithEvents btnPlay As Button
    Friend WithEvents BtnScore1 As Button
    Friend WithEvents BtnScore2 As Button
End Class
